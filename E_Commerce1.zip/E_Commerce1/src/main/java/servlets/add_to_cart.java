package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/add_to_cart")
public class add_to_cart extends HttpServlet {

    private static final long serialVersionUID = 1L;
    
    
 
	@Override
	public void init(ServletConfig config) throws ServletException {
		
	}
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =response.getWriter();
		
			int id= Integer.parseInt(request.getParameter("id"));
			
		out.print(id);
		}
	
	@Override
	public void destroy() {
		
	}

} 