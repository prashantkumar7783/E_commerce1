package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Product; 

public class Product_Dao {

	
	private PreparedStatement pst;
	private String query;
	private ResultSet rs;
	private Connection con;
	
	public Product_Dao(Connection con) {
	    this.con = con;
	}

		
		public List<Product>getAllProduct() throws SQLException{
			ArrayList<Product>pro=new  ArrayList<Product>();
			query="select * from bike";
			  
			pst= con.prepareStatement(query);
			rs=pst.executeQuery();
			while(rs.next()) {
				Product p1=new Product();
				p1.setId(rs.getInt("id"));
				p1.setTitle(rs.getString("title"));
				p1.setDetails(rs.getString("deatils"));
				p1.setPrice(rs.getDouble("price"));
				p1.setImage(rs.getString("image"));
				
				pro.add(p1); 
				
			
			}
			
			
			return pro;
		}
}
