package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;




public class DB_Connection {
	
	
	public static Connection getConn() throws SQLException
	{
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aptron", "root", "admin");
		return con;
	}

}